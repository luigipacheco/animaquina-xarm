# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Animaquina-UF",
    "author" : "Luis Pacheco", 
    "description" : "An addon for robot  control and toolpathing",
    "blender" : (4, 2, 0),
    "version" : (0, 0, 8),
    "location" : "",
    "warning" : "Use at your own risk!",
    "doc_url": "www.animaquina.com", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import bpy, bmesh
import os
import time
import bmesh
from mathutils import Euler
import random
from xarm.wrapper import XArmAPI
import blf


addon_keymaps = {}
_icons = None
class dotdict(dict):
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


class SNA_OT_Disconnect__Robot_B5347(bpy.types.Operator):
    bl_idname = "sna.disconnect__robot_b5347"
    bl_label = "Disconnect  Robot"
    bl_description = "Disconnect current robot"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_B8CFE = disconnect()
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class SNA_OT_Connect_Robot_3Efab(bpy.types.Operator):
    bl_idname = "sna.connect_robot_3efab"
    bl_label = "Connect Robot"
    bl_description = "Connect robot on the selected IP"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_CE206 = connect()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Update_Pose_D5D92(bpy.types.Operator):
    bl_idname = "sna.update_pose_d5d92"
    bl_label = "update pose"
    bl_description = "Force read and update the current robot joints on the sumulation"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_4C5AF = update_pose()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Manualmode_Edd6D(bpy.types.Operator):
    bl_idname = "sna.manualmode_edd6d"
    bl_label = "manualmode"
    bl_description = "Start/ Stop manual mode"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_40C38 = manualMode()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Addmarker_2E3A1(bpy.types.Operator):
    bl_idname = "sna.addmarker_2e3a1"
    bl_label = "addmarker"
    bl_description = "Add an empty on the current robot position"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_99804 = addMarker()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Home_47Dfc(bpy.types.Operator):
    bl_idname = "sna.home_47dfc"
    bl_label = "home"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_67E4E = go_home()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Jog_13671(bpy.types.Operator):
    bl_idname = "sna.jog_13671"
    bl_label = "jog"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_94F37 = jog()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Installsdk_F915B(bpy.types.Operator):
    bl_idname = "sna.installsdk_f915b"
    bl_label = "installsdk"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_SETUP_2240C(bpy.types.Panel):
    bl_label = 'Setup'
    bl_idname = 'SNA_PT_SETUP_2240C'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Animaquina'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_34D3E = layout.column(heading='Connect', align=True)
        col_34D3E.alert = False
        col_34D3E.enabled = True
        col_34D3E.active = True
        col_34D3E.use_property_split = False
        col_34D3E.use_property_decorate = False
        col_34D3E.scale_x = 1.0
        col_34D3E.scale_y = 1.0
        col_34D3E.alignment = 'Expand'.upper()
        col_34D3E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_34D3E.prop_search(bpy.context.scene, 'sna_robot', bpy.data, 'objects', text='Robot', icon='TRACKING_BACKWARDS_SINGLE')
        col_34D3E.prop(bpy.context.scene, 'sna_ip', text='IP ', icon_value=0, emboss=True, slider=False)
        op = col_34D3E.operator('sna.connect_robot_3efab', text='Connect Robot', icon_value=0, emboss=True, depress=False)
        op = col_34D3E.operator('sna.disconnect__robot_b5347', text='Disconnect Robot', icon_value=0, emboss=True, depress=False)
        col_7E02D = layout.column(heading='Cell', align=True)
        col_7E02D.alert = False
        col_7E02D.enabled = True
        col_7E02D.active = True
        col_7E02D.use_property_split = False
        col_7E02D.use_property_decorate = True
        col_7E02D.scale_x = 1.0
        col_7E02D.scale_y = 1.0
        col_7E02D.alignment = 'Expand'.upper()
        col_7E02D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"


class SNA_PT_TOOLPATHING_95AA3(bpy.types.Panel):
    bl_label = 'Toolpathing'
    bl_idname = 'SNA_PT_TOOLPATHING_95AA3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Animaquina'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_B7431 = layout.column(heading='', align=True)
        col_B7431.alert = False
        col_B7431.enabled = True
        col_B7431.active = True
        col_B7431.use_property_split = False
        col_B7431.use_property_decorate = False
        col_B7431.scale_x = 1.0
        col_B7431.scale_y = 1.0
        col_B7431.alignment = 'Left'.upper()
        col_B7431.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        grid_5C92B = col_B7431.grid_flow(columns=3, row_major=False, even_columns=False, even_rows=False, align=True)
        grid_5C92B.enabled = True
        grid_5C92B.active = True
        grid_5C92B.use_property_split = False
        grid_5C92B.use_property_decorate = False
        grid_5C92B.alignment = 'Expand'.upper()
        grid_5C92B.scale_x = 1.0
        grid_5C92B.scale_y = 1.0
        if not True: grid_5C92B.operator_context = "EXEC_DEFAULT"
        grid_5C92B.label(text='Acc', icon_value=0)
        grid_5C92B.label(text='Vel', icon_value=0)
        grid_5C92B.label(text='Rad', icon_value=0)
        grid_29258 = col_B7431.grid_flow(columns=3, row_major=False, even_columns=False, even_rows=False, align=True)
        grid_29258.enabled = True
        grid_29258.active = True
        grid_29258.use_property_split = False
        grid_29258.use_property_decorate = False
        grid_29258.alignment = 'Expand'.upper()
        grid_29258.scale_x = 1.0
        grid_29258.scale_y = 1.0
        if not True: grid_29258.operator_context = "EXEC_DEFAULT"
        grid_29258.prop(bpy.context.scene, 'sna_vel', text='Acceleration', icon_value=0, emboss=True, slider=True)
        grid_29258.prop(bpy.context.scene, 'sna_vel', text='Velocity', icon_value=0, emboss=True, slider=True)
        grid_29258.prop(bpy.context.scene, 'sna_rad', text='Radius', icon_value=21, emboss=True, slider=True)
        op = col_B7431.operator('sna.runpath_c74d7', text='Path', icon_value=274, emboss=True, depress=False)
        op = col_B7431.operator('sna.addmarker_2e3a1', text='Add Marker', icon_value=320, emboss=True, depress=False)
        op = col_B7431.operator('sna.debug_c0948', text='Use Inches', icon_value=582, emboss=True, depress=False)


class SNA_OT_Runpathold_D30Df(bpy.types.Operator):
    bl_idname = "sna.runpathold_d30df"
    bl_label = "Runpathold"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_4B1B0 = runPathold()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Debug_C0948(bpy.types.Operator):
    bl_idname = "sna.debug_c0948"
    bl_label = "debug"
    bl_description = "Inches? What is this, the 19th century?"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_DD752 = debug()
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.label(text='Fun fact: inches are banned in cool places.', icon_value=0)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


_C6C51_running = False
class SNA_OT_Realtime_C6C51(bpy.types.Operator):
    bl_idname = "sna.realtime_c6c51"
    bl_label = "realtime"
    bl_description = "Update robot twin on real time. "
    bl_options = {"REGISTER", "UNDO"}
    cursor = "DEFAULT"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceView3D':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _C6C51_running
        _C6C51_running = False
        context.window.cursor_set("DEFAULT")
        import math

        def before_modal():
            # Preparation code here
            print("Preparing for real-time armature updates...")
            bpy.context.scene.sna_realtime= True

        def modal():
            get_robotTCP()
            get_robotPose()
            update_twin_angles(bpy.context.scene.sna_robot.name )
            return {'PASS_THROUGH'}  # or {'FINISHED'} to end the modal operation

        def after_modal():
            print("Finished real-time armature updates.")
            bpy.context.scene.sna_realtime= False
            # Restore the original selection state, if necessary
            bpy.ops.object.select_all(action='DESELECT')
            for obj in bpy.context.selected_objects[:]:  # Assuming you stored these earlier
                obj.select_set(True)
            update_pose()
        return_F2A4B = after_modal()
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _C6C51_running
        if not context.area or not _C6C51_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('DEFAULT')
        try:
            import math

            def before_modal():
                # Preparation code here
                print("Preparing for real-time armature updates...")
                bpy.context.scene.sna_realtime= True

            def modal():
                get_robotTCP()
                get_robotPose()
                update_twin_angles(bpy.context.scene.sna_robot.name )
                return {'PASS_THROUGH'}  # or {'FINISHED'} to end the modal operation

            def after_modal():
                print("Finished real-time armature updates.")
                bpy.context.scene.sna_realtime= False
                # Restore the original selection state, if necessary
                bpy.ops.object.select_all(action='DESELECT')
                for obj in bpy.context.selected_objects[:]:  # Assuming you stored these earlier
                    obj.select_set(True)
                update_pose()
            return_C6C81 = modal()
        except Exception as error:
            print(error)
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _C6C51_running
        if _C6C51_running:
            _C6C51_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            import math

            def before_modal():
                # Preparation code here
                print("Preparing for real-time armature updates...")
                bpy.context.scene.sna_realtime= True

            def modal():
                get_robotTCP()
                get_robotPose()
                update_twin_angles(bpy.context.scene.sna_robot.name )
                return {'PASS_THROUGH'}  # or {'FINISHED'} to end the modal operation

            def after_modal():
                print("Finished real-time armature updates.")
                bpy.context.scene.sna_realtime= False
                # Restore the original selection state, if necessary
                bpy.ops.object.select_all(action='DESELECT')
                for obj in bpy.context.selected_objects[:]:  # Assuming you stored these earlier
                    obj.select_set(True)
                update_pose()
            return_A1E74 = before_modal()
            context.window_manager.modal_handler_add(self)
            _C6C51_running = True
            return {'RUNNING_MODAL'}


_C74D7_running = False
class SNA_OT_Runpath_C74D7(bpy.types.Operator):
    bl_idname = "sna.runpath_c74d7"
    bl_label = "runPath"
    bl_description = "Follow the selected path"
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _C74D7_running
        _C74D7_running = False
        context.window.cursor_set("DEFAULT")
        from mathutils import Vector

        def prepare_paths():
            print("preparing path")
            obj = bpy.context.active_object
            if obj.mode == 'EDIT':
                bm = bmesh.from_edit_mesh(obj.data)
            else:
                bm = bmesh.new()
                bm.from_mesh(obj.data)
            vertices = [v for v in bm.verts]
            verts = [obj.matrix_world @ vert.co for vert in vertices]
            verts = [vert * 1000 for vert in verts]

            def are_connected(v1_index, v2_index):
                for edge in bm.edges:
                    if vertices[v1_index] in edge.verts and vertices[v2_index] in edge.verts:
                        return True
                return False
            paths = []
            new_segment = True
            for i, v in enumerate(verts):
                if new_segment:
                    retract_start = Vector(v) + Vector((0, 0, 20))
                    paths.append([retract_start.x, retract_start.y, retract_start.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                    new_segment = False
                paths.append([v.x, v.y, v.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                if i < len(verts) - 1 and not are_connected(i, i + 1):
                    retract_end = Vector(v) + Vector((0, 0, 20))
                    paths.append([retract_end.x, retract_end.y, retract_end.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                    new_segment = True
            if verts:
                final_retract = Vector(verts[-1]) + Vector((0, 0, 20))
                paths.append([final_retract.x, final_retract.y, final_retract.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
            if obj.mode != 'EDIT':
                bm.free()
            robot.set_position(*paths[0], wait=False)
            _, angles = robot.get_servo_angle()
            robot.set_pause_time(0.2)
            print("path prepared")
            return paths, angles
        #def modal_execute(paths,angles):
        #    def ptp():
        #        ret = arm.set_servo_angle(angle=angles, speed=50, wait=True)
        #        if ret < 0:
        #            print('set_servo_angle, ret={}'.format(ret))
        #            return -1
        #        for path in paths:
        #            ret = arm.set_position(*path[:6], radius=0, wait=False, speed=100)
        #            if ret < 0:
        #                print('set_position, ret={}'.format(ret))
        #                return -1
        #        return 0
        #    for i in range(1):
        #        if ptp() != 0:
        #            break

        def modal_execute(paths, angles):

            def ptp():
                # Set initial servo angles
                #ret = arm.set_servo_angle(angle=angles, speed=50, wait=False)
                ret = robot.set_position(*paths[0], wait=False)
                if ret < 0:
                    print(f'set_servo_angle, ret={ret}')
                    return -1
                for path in paths:
                    # Move to the next point in the path
                    ret = robot.set_position(*path[:6], radius=bpy.context.scene.sna_rad, wait=False, speed=bpy.context.scene.sna_vel)
                    if ret < 0:
                        print(f'set_position, ret={ret}')
                        return -1
                return 0
            # Execute the point-to-point movement
            if ptp() != 0:
                print("Error during path execution")
                return {'CANCELLED'}  # Use Blender's return conventions for modal operators
            return {'FINISHED'}

        def cleanup():
            get_robotPos()
            print("Path Done!!")
            # Additional cleanup actions can be added here
        return_40068 = cleanup()
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _C74D7_running
        if not context.area or not _C74D7_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:
            from mathutils import Vector

            def prepare_paths():
                print("preparing path")
                obj = bpy.context.active_object
                if obj.mode == 'EDIT':
                    bm = bmesh.from_edit_mesh(obj.data)
                else:
                    bm = bmesh.new()
                    bm.from_mesh(obj.data)
                vertices = [v for v in bm.verts]
                verts = [obj.matrix_world @ vert.co for vert in vertices]
                verts = [vert * 1000 for vert in verts]

                def are_connected(v1_index, v2_index):
                    for edge in bm.edges:
                        if vertices[v1_index] in edge.verts and vertices[v2_index] in edge.verts:
                            return True
                    return False
                paths = []
                new_segment = True
                for i, v in enumerate(verts):
                    if new_segment:
                        retract_start = Vector(v) + Vector((0, 0, 20))
                        paths.append([retract_start.x, retract_start.y, retract_start.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                        new_segment = False
                    paths.append([v.x, v.y, v.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                    if i < len(verts) - 1 and not are_connected(i, i + 1):
                        retract_end = Vector(v) + Vector((0, 0, 20))
                        paths.append([retract_end.x, retract_end.y, retract_end.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                        new_segment = True
                if verts:
                    final_retract = Vector(verts[-1]) + Vector((0, 0, 20))
                    paths.append([final_retract.x, final_retract.y, final_retract.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                if obj.mode != 'EDIT':
                    bm.free()
                robot.set_position(*paths[0], wait=False)
                _, angles = robot.get_servo_angle()
                robot.set_pause_time(0.2)
                print("path prepared")
                return paths, angles
            #def modal_execute(paths,angles):
            #    def ptp():
            #        ret = arm.set_servo_angle(angle=angles, speed=50, wait=True)
            #        if ret < 0:
            #            print('set_servo_angle, ret={}'.format(ret))
            #            return -1
            #        for path in paths:
            #            ret = arm.set_position(*path[:6], radius=0, wait=False, speed=100)
            #            if ret < 0:
            #                print('set_position, ret={}'.format(ret))
            #                return -1
            #        return 0
            #    for i in range(1):
            #        if ptp() != 0:
            #            break

            def modal_execute(paths, angles):

                def ptp():
                    # Set initial servo angles
                    #ret = arm.set_servo_angle(angle=angles, speed=50, wait=False)
                    ret = robot.set_position(*paths[0], wait=False)
                    if ret < 0:
                        print(f'set_servo_angle, ret={ret}')
                        return -1
                    for path in paths:
                        # Move to the next point in the path
                        ret = robot.set_position(*path[:6], radius=bpy.context.scene.sna_rad, wait=False, speed=bpy.context.scene.sna_vel)
                        if ret < 0:
                            print(f'set_position, ret={ret}')
                            return -1
                    return 0
                # Execute the point-to-point movement
                if ptp() != 0:
                    print("Error during path execution")
                    return {'CANCELLED'}  # Use Blender's return conventions for modal operators
                return {'FINISHED'}

            def cleanup():
                get_robotPos()
                print("Path Done!!")
                # Additional cleanup actions can be added here
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _C74D7_running
        if _C74D7_running:
            _C74D7_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            from mathutils import Vector

            def prepare_paths():
                print("preparing path")
                obj = bpy.context.active_object
                if obj.mode == 'EDIT':
                    bm = bmesh.from_edit_mesh(obj.data)
                else:
                    bm = bmesh.new()
                    bm.from_mesh(obj.data)
                vertices = [v for v in bm.verts]
                verts = [obj.matrix_world @ vert.co for vert in vertices]
                verts = [vert * 1000 for vert in verts]

                def are_connected(v1_index, v2_index):
                    for edge in bm.edges:
                        if vertices[v1_index] in edge.verts and vertices[v2_index] in edge.verts:
                            return True
                    return False
                paths = []
                new_segment = True
                for i, v in enumerate(verts):
                    if new_segment:
                        retract_start = Vector(v) + Vector((0, 0, 20))
                        paths.append([retract_start.x, retract_start.y, retract_start.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                        new_segment = False
                    paths.append([v.x, v.y, v.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                    if i < len(verts) - 1 and not are_connected(i, i + 1):
                        retract_end = Vector(v) + Vector((0, 0, 20))
                        paths.append([retract_end.x, retract_end.y, retract_end.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                        new_segment = True
                if verts:
                    final_retract = Vector(verts[-1]) + Vector((0, 0, 20))
                    paths.append([final_retract.x, final_retract.y, final_retract.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                if obj.mode != 'EDIT':
                    bm.free()
                robot.set_position(*paths[0], wait=False)
                _, angles = robot.get_servo_angle()
                robot.set_pause_time(0.2)
                print("path prepared")
                return paths, angles
            #def modal_execute(paths,angles):
            #    def ptp():
            #        ret = arm.set_servo_angle(angle=angles, speed=50, wait=True)
            #        if ret < 0:
            #            print('set_servo_angle, ret={}'.format(ret))
            #            return -1
            #        for path in paths:
            #            ret = arm.set_position(*path[:6], radius=0, wait=False, speed=100)
            #            if ret < 0:
            #                print('set_position, ret={}'.format(ret))
            #                return -1
            #        return 0
            #    for i in range(1):
            #        if ptp() != 0:
            #            break

            def modal_execute(paths, angles):

                def ptp():
                    # Set initial servo angles
                    #ret = arm.set_servo_angle(angle=angles, speed=50, wait=False)
                    ret = robot.set_position(*paths[0], wait=False)
                    if ret < 0:
                        print(f'set_servo_angle, ret={ret}')
                        return -1
                    for path in paths:
                        # Move to the next point in the path
                        ret = robot.set_position(*path[:6], radius=bpy.context.scene.sna_rad, wait=False, speed=bpy.context.scene.sna_vel)
                        if ret < 0:
                            print(f'set_position, ret={ret}')
                            return -1
                    return 0
                # Execute the point-to-point movement
                if ptp() != 0:
                    print("Error during path execution")
                    return {'CANCELLED'}  # Use Blender's return conventions for modal operators
                return {'FINISHED'}

            def cleanup():
                get_robotPos()
                print("Path Done!!")
                # Additional cleanup actions can be added here
            return_B03E7 = prepare_paths()
            return_69712 = modal_execute(return_B03E7[0], return_B03E7[1])
            context.window_manager.modal_handler_add(self)
            _C74D7_running = True
            return {'RUNNING_MODAL'}


###setup


import sys
import math
from mathutils import Vector


def connect():
    global robot
    robot = XArmAPI(bpy.context.scene.sna_ip)
    robot.motion_enable(enable=True)
    robot.set_mode(0)
    robot.set_state(state=0)
    update_pose()
    print("Conection Up")
    return robot


def disconnect():
    robot.disconnect()
    armature_name = bpy.context.scene.sna_robot.name 
    tcp_name = bpy.context.scene.sna_tcp.name 
    armature_obj = bpy.data.objects.get(armature_name)
    for pb in armature_obj.pose.bones:
        pb.matrix_basis.identity()
        bpy.ops.pose.transforms_clear.poll()
    bpy.context.scene.sna_x = 0
    bpy.context.scene.sna_y = 0
    bpy.context.scene.sna_z = 0
    bpy.context.scene.sna_a = 0
    bpy.context.scene.sna_b = 0
    bpy.context.scene.sna_c = 0
    bpy.context.scene.sna_j1 = 0
    bpy.context.scene.sna_j2 = 0
    bpy.context.scene.sna_j3 = 0
    bpy.context.scene.sna_j4 = 0
    bpy.context.scene.sna_j5 = 0
    bpy.context.scene.sna_j6 = 0
    tcp_obj = bpy.data.objects.get(tcp_name)
    tcp_obj.location = [0 ,0 ,0]
    tcp_obj.rotation_euler = [-math.pi/2,math.pi,math.pi]
    print("Robot Disconected")


def get_robotTCP():
    robotscale = 0.001
    currentPos = robot.get_position()
    bpy.context.scene.sna_x = currentPos[1][0] * robotscale
    bpy.context.scene.sna_y = currentPos[1][1] * robotscale
    bpy.context.scene.sna_z = currentPos[1][2] * robotscale
    bpy.context.scene.sna_a = currentPos[1][3] 
    bpy.context.scene.sna_b = currentPos[1][4] 
    bpy.context.scene.sna_c = currentPos[1][5] 
    print("TCP:")
    print(currentPos)


def get_robotPose(): # don't change!
    currentPose = robot.get_servo_angle(is_radian=True)
    bpy.context.scene.sna_j1 = math.degrees(currentPose[1][0])
    bpy.context.scene.sna_j2 = math.degrees(currentPose[1][1])
    bpy.context.scene.sna_j3 = math.degrees(currentPose[1][2])
    bpy.context.scene.sna_j4 = math.degrees(currentPose[1][3])
    bpy.context.scene.sna_j5 = math.degrees(currentPose[1][4])
    bpy.context.scene.sna_j6 = math.degrees(currentPose[1][5])
    print("Pose:")
    print(currentPose)


def update_twin_angles(armature_name):
    # Update Angles
    joint_angles = [
        bpy.context.scene.sna_j1,
        bpy.context.scene.sna_j2,
        bpy.context.scene.sna_j3,
        bpy.context.scene.sna_j4,
        bpy.context.scene.sna_j5,
        bpy.context.scene.sna_j6,
    ]
    if len(joint_angles) > 6:
        joint_angles = joint_angles[:6]
    print("Joint Angles:", joint_angles)
    armature_obj = bpy.data.objects.get(armature_name)
    if armature_obj is None or armature_obj.type != 'ARMATURE':
        print(f"Armature named '{armature_name}' not found or not an armature.")
        return
    rotation_axes = []
    if bpy.context.scene.sna_robot and bpy.context.scene.sna_robot.name == "ufxarm6_twin":
        rotation_axes = ['Y', '-Z', '-Z', 'Y', '-Z', 'Y']  # xarm6
    elif bpy.context.scene.sna_robot and bpy.context.scene.sna_robot.name == "uf850_twin":
        rotation_axes = ['Y', 'Z', '-Z', 'Y', 'Z', 'Y']  # 850
    else:
        print(f"Warning: Unknown robot name: {getattr(bpy.context.scene.sna_robot, 'name', 'None')}")
    # Ensure rotation_axes is valid for further processing
    if not rotation_axes:
        raise ValueError("rotation_axes is not defined. Please check the robot configuration.")
    for i, (angle, axis) in enumerate(zip(joint_angles, rotation_axes)):
        # Check if the axis has a '-' prefix, invert the angle if needed
        if axis.startswith('-'):
            angle *= -1
            axis = axis[1:]  # Remove the '-' for axis identification
        bone_name = f"joint_{i+1}"
        bone = armature_obj.pose.bones.get(bone_name)
        if bone:
            bone.rotation_mode = 'XYZ'
            if axis == 'X':
                bone.rotation_euler[0] = math.radians(angle)
            elif axis == 'Y':
                bone.rotation_euler[1] = math.radians(angle)
            elif axis == 'Z':
                bone.rotation_euler[2] = math.radians(angle)
            else:
                print(f"Unsupported axis '{axis}' for bone '{bone_name}'.")
        else:
            print(f"No bone named '{bone_name}' found in armature '{armature_name}'.")
    # Update the scene to reflect changes
    bpy.context.view_layer.update()
    print("Twin angles updated.")


def update_tcp():  
    bpy.context.scene.sna_tcp.location[0] =  bpy.context.scene.sna_x 
    bpy.context.scene.sna_tcp.location[1] =   bpy.context.scene.sna_y
    bpy.context.scene.sna_tcp.location[2] =   bpy.context.scene.sna_z
    rpy = (math.radians(bpy.context.scene.sna_a), math.radians(bpy.context.scene.sna_b), math.radians(bpy.context.scene.sna_c))
    bpy.context.scene.sna_tcp.rotation_euler[0] =   rpy[0]
    bpy.context.scene.sna_tcp.rotation_euler[1] =   rpy[1]
    bpy.context.scene.sna_tcp.rotation_euler[2] =   rpy[2]


#    bpy.context.scene.sna_tcp.rotation_euler[0] =   bpy.context.scene.sna_a
#    bpy.context.scene.sna_tcp.rotation_euler[1] =   bpy.context.scene.sna_b
#    bpy.context.scene.sna_tcp.rotation_euler[2] =   bpy.context.scene.sna_c
    print("update sim: ")
    print(rpy)


def update_pose():
    get_robotTCP()
    get_robotPose()
    update_twin_angles(bpy.context.scene.sna_robot.name) 
    update_tcp()


#    


def addMarker():
    update_pose()
    bpy.ops.object.empty_add(type='PLAIN_AXES',radius=.1,location=[bpy.context.scene.sna_x,bpy.context.scene.sna_y,bpy.context.scene.sna_z])  


def goTo():
    robotscale = 1000
    robot.motion_enable(enable=True)
    robot.set_mode(0)
    robot.set_state(state=0)
    current_position = robot.get_position()[1]
    newPos = [bpy.context.scene.sna_tcp.location[0]*robotscale,bpy.context.scene.sna_tcp.location[1]*robotscale,bpy.context.scene.sna_tcp.location[2]*robotscale,math.degrees(bpy.context.scene.sna_tcp.rotation_euler[0]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[1]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[2])]
    print(newPos)
    distance_to_target = math.sqrt(sum([(a - b) ** 2 for a, b in zip(current_position[:3], newPos[:3])]))
    robot.set_position(x=newPos[0] , y=newPos[1] , z=newPos[2] , roll=newPos[3], pitch=newPos[4], yaw=newPos[5], speed=100,wait=False)
    print("start")
    while round(distance_to_target, 4) > 0.1:
        current_position = robot.get_position()[1]
        distance_to_target = math.sqrt(sum([(a - b) ** 2 for a, b in zip(current_position[:3], newPos[:3])]))
        print(print(round(distance_to_target, 4)))
    print("done") 
    update_pose()


def go_home():
    robot.move_gohome(wait=True)
    print("Robot homed!")
    update_pose()   


def manualMode():
    if bpy.context.scene.sna_manualmode == False:
        robot.set_mode(2)
        robot.set_state(0)
        print("manual mode ON")
        bpy.context.scene.sna_manualmode= True
    else:
        robot.set_mode(0)
        robot.set_state(state=0)
        print("manual mode OFF")
        bpy.context.scene.sna_manualmode= False


#def setTool():
#    # Ensure tool is active and selected
#    tool = bpy.context.scene.sna_tool
#    tcp = bpy.context.scene.sna_tcp
#    # Check if both tool and tcp are set correctly
#    if tool and tcp:
#        # Make sure the tool is the active object
#        bpy.context.view_layer.objects.active = tool
#        tool.select_set(True)
#        # Add the 'CHILD_OF' constraint to the tool
#        constraint = tool.constraints.new(type='CHILD_OF')
#        constraint.name = "tool_constraint"  # Name it to ensure consistent access
#        constraint.target = tcp
#        # Update the scene to ensure all transformations are applied
#        bpy.context.view_layer.update()
#        # Clear the inverse using the operator in the correct context
#        bpy.ops.object.select_all(action='DESELECT')  # Deselect all to ensure clean context
#        tool.select_set(True)  # Select the tool object again
#        bpy.context.view_layer.objects.active = tool  # Make tool the active object
#        bpy.ops.constraint.childof_clear_inverse(constraint="tool_constraint", owner='OBJECT')
#        
#        print(f"Constraint 'Child Of' set on {tool.name} with target {tcp.name}, and inverse cleared.")
#    else:
#        print("Tool or TCP object not found in the scene.")
#    


def debug():
    quotes = [
        "Keep trying! Centimeters are just inches that believed in themselves.",
        "Almost there! Maybe if you believe in the metric system...",
        "Inches? What is this, the 19th century?",
        "Fun fact: inches are banned in cool places.",
        "Inches? Sounds like you want feet. Try again.",
        "Close, but no ruler! Stick to the metrics.",
        "Inches unlocked! Just kidding, it's still centimeters.",
        "Congrats! You found the 'not gonna happen' button.",
        "Inches are like unicorns—beautiful but imaginary (at least here).",
        "You clicked inches! Somewhere, a metric user sheds a single tear."
    ]
    text =  random.choice(quotes)
    print(text)


def setSimulation():
    collection_name = bpy.context.scene.sna_simcollection.name
    if collection_name in bpy.data.collections:
        collection = bpy.data.collections[collection_name]
        # Rename objects, armatures, and bones
        for obj in collection.objects:
            new_name = obj.name.replace('twin', 'sim')
            if new_name.endswith(".001"):
                new_name = new_name.rsplit(".001", 1)[0]
            obj.name = new_name
            if obj.type == 'ARMATURE':
                for bone in obj.data.bones:
                    bone_name = bone.name.replace('twin', 'sim')
                    if bone_name.endswith(".001"):
                        bone_name = bone_name.rsplit(".001", 1)[0]
                    bone.name = bone_name
                if obj.pose:
                    for pose_bone in obj.pose.bones:
                        pose_bone_name = pose_bone.name.replace('twin', 'sim')
                        if pose_bone_name.endswith(".001"):
                            pose_bone_name = pose_bone_name.rsplit(".001", 1)[0]
                        pose_bone.name = pose_bone_name
                # Apply current pose as rest position for the armature
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.armature_apply()
                # Return to Object Mode after applying the pose
                bpy.ops.object.mode_set(mode='OBJECT')
                # Setting up the IK constraint on 'joint_6' to target 'tcp'
                joint_6 = obj.pose.bones.get("joint_6")
                tcp_bone = obj.pose.bones.get("tcp")
                if joint_6 and tcp_bone:
                    # Add an IK constraint to 'joint_6'
                    ik_constraint = joint_6.constraints.new(type='IK')
                    ik_constraint.target = obj
                    ik_constraint.subtarget = "tcp"
                    ik_constraint.use_rotation = True
                    print("IK constraint set on 'joint_6' targeting 'tcp' with rotation enabled.")
                    # Add a "Child Of" constraint to 'tcp'
                    child_of_constraint = tcp_bone.constraints.new(type='CHILD_OF')
                    target_obj = bpy.context.scene.sna_tcp  
                    if target_obj:
                        child_of_constraint.target = target_obj
                        print("Child Of constraint set on 'tcp' targeting the object in 'sna_tcp'.")
                    else:
                        print("Target object in 'sna_tcp' not found in scene properties.")
                else:
                    print("Bones 'joint_6' or 'tcp' not found in the armature.")
        # Rename the collection itself
        new_collection_name = collection.name.replace('twin', 'sim')
        if new_collection_name.endswith(".001"):
            new_collection_name = new_collection_name.rsplit(".001", 1)[0]
        collection.name = new_collection_name
        print(f"Setup completed for collection '{new_collection_name}' and rest position applied.")
    else:
        print(f"Collection '{collection_name}' not found.")


_BCB48_running = False
class SNA_OT_Gototargetmod_Bcb48(bpy.types.Operator):
    bl_idname = "sna.gototargetmod_bcb48"
    bl_label = "goToTargetmod"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not True or context.area.spaces[0].bl_rna.identifier == 'SpaceView3D':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _BCB48_running
        _BCB48_running = False
        context.window.cursor_set("DEFAULT")
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _BCB48_running
        if not context.area or not _BCB48_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.area.tag_redraw()
        context.window.cursor_set('CROSSHAIR')
        try:
            pass
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _BCB48_running
        if _BCB48_running:
            _BCB48_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            args = (context,)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            _BCB48_running = True
            return {'RUNNING_MODAL'}


_746A0_running = False
class SNA_OT_Gotort_746A0(bpy.types.Operator):
    bl_idname = "sna.gotort_746a0"
    bl_label = "goToRT"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _746A0_running
        _746A0_running = False
        context.window.cursor_set("DEFAULT")
        from mathutils import Vector

        def prepare_paths():
            robotscale=1000
            print("preparing move")
            paths = []
            current_position = robot.get_position()[1]
            newPos = [bpy.context.scene.sna_tcp.location[0]*robotscale,bpy.context.scene.sna_tcp.location[1]*robotscale,bpy.context.scene.sna_tcp.location[2]*robotscale,math.degrees(bpy.context.scene.sna_tcp.rotation_euler[0]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[1]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[2])]
            paths.append(current_position)
            paths.append(newPos)
            _, angles = robot.get_servo_angle()
            print("ready to move")
            return paths, angles

        def modal_execute(paths, angles):

            def ptp():
                # Set initial servo angles
                ret = robot.set_servo_angle(angle=angles, speed=bpy.context.scene.sna_vel, wait=False)
                if ret < 0:
                    print(f'set_servo_angle, ret={ret}')
                    return -1
                for path in paths:
                    # Move to the next point in the path
                    ret = robot.set_position(*path[:6], radius=bpy.context.scene.sna_rad, wait=False, speed=bpy.context.scene.sna_vel)
                    if ret < 0:
                        print(f'set_position, ret={ret}')
                        return -1
                return 0
            # Execute the point-to-point movement
            if ptp() != 0:
                print("Error during path execution")
                return {'CANCELLED'}  # Use Blender's return conventions for modal operators
            #get_robotPos()
            print("Path Done!!")
            return {'FINISHED'}

        def cleanup():
            update_pose()
            print("DONE!!")
            return {'FINISHED'}
            # Additional cleanup actions can be added here
        return_1C74E = cleanup()
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _746A0_running
        if not context.area or not _746A0_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:
            from mathutils import Vector

            def prepare_paths():
                robotscale=1000
                print("preparing move")
                paths = []
                current_position = robot.get_position()[1]
                newPos = [bpy.context.scene.sna_tcp.location[0]*robotscale,bpy.context.scene.sna_tcp.location[1]*robotscale,bpy.context.scene.sna_tcp.location[2]*robotscale,math.degrees(bpy.context.scene.sna_tcp.rotation_euler[0]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[1]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[2])]
                paths.append(current_position)
                paths.append(newPos)
                _, angles = robot.get_servo_angle()
                print("ready to move")
                return paths, angles

            def modal_execute(paths, angles):

                def ptp():
                    # Set initial servo angles
                    ret = robot.set_servo_angle(angle=angles, speed=bpy.context.scene.sna_vel, wait=False)
                    if ret < 0:
                        print(f'set_servo_angle, ret={ret}')
                        return -1
                    for path in paths:
                        # Move to the next point in the path
                        ret = robot.set_position(*path[:6], radius=bpy.context.scene.sna_rad, wait=False, speed=bpy.context.scene.sna_vel)
                        if ret < 0:
                            print(f'set_position, ret={ret}')
                            return -1
                    return 0
                # Execute the point-to-point movement
                if ptp() != 0:
                    print("Error during path execution")
                    return {'CANCELLED'}  # Use Blender's return conventions for modal operators
                #get_robotPos()
                print("Path Done!!")
                return {'FINISHED'}

            def cleanup():
                update_pose()
                print("DONE!!")
                return {'FINISHED'}
                # Additional cleanup actions can be added here
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _746A0_running
        if _746A0_running:
            _746A0_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            from mathutils import Vector

            def prepare_paths():
                robotscale=1000
                print("preparing move")
                paths = []
                current_position = robot.get_position()[1]
                newPos = [bpy.context.scene.sna_tcp.location[0]*robotscale,bpy.context.scene.sna_tcp.location[1]*robotscale,bpy.context.scene.sna_tcp.location[2]*robotscale,math.degrees(bpy.context.scene.sna_tcp.rotation_euler[0]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[1]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[2])]
                paths.append(current_position)
                paths.append(newPos)
                _, angles = robot.get_servo_angle()
                print("ready to move")
                return paths, angles

            def modal_execute(paths, angles):

                def ptp():
                    # Set initial servo angles
                    ret = robot.set_servo_angle(angle=angles, speed=bpy.context.scene.sna_vel, wait=False)
                    if ret < 0:
                        print(f'set_servo_angle, ret={ret}')
                        return -1
                    for path in paths:
                        # Move to the next point in the path
                        ret = robot.set_position(*path[:6], radius=bpy.context.scene.sna_rad, wait=False, speed=bpy.context.scene.sna_vel)
                        if ret < 0:
                            print(f'set_position, ret={ret}')
                            return -1
                    return 0
                # Execute the point-to-point movement
                if ptp() != 0:
                    print("Error during path execution")
                    return {'CANCELLED'}  # Use Blender's return conventions for modal operators
                #get_robotPos()
                print("Path Done!!")
                return {'FINISHED'}

            def cleanup():
                update_pose()
                print("DONE!!")
                return {'FINISHED'}
                # Additional cleanup actions can be added here
            return_B925A = prepare_paths()
            return_36871 = modal_execute(paths=return_B925A[0], angles=return_B925A[1])
            context.window_manager.modal_handler_add(self)
            _746A0_running = True
            return {'RUNNING_MODAL'}


class SNA_OT_Gototarget_2Cfb1(bpy.types.Operator):
    bl_idname = "sna.gototarget_2cfb1"
    bl_label = "goToTarget"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_AD7B0 = goTo()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


_A4C67_running = False
class SNA_OT_Testptp_A4C67(bpy.types.Operator):
    bl_idname = "sna.testptp_a4c67"
    bl_label = "testptp"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _A4C67_running
        _A4C67_running = False
        context.window.cursor_set("DEFAULT")

        def before():
            robot.motion_enable(enable=True)
            robot.set_mode(0)
            robot.set_state(state=0)
            current_position = robot.get_position()[1]
            newPos = [bpy.context.scene.sna_tcp.location[0],bpy.context.scene.sna_tcp.location[1],bpy.context.scene.sna_tcp.location[2],math.degrees(bpy.context.scene.sna_tcp.rotation_euler[0])+180,math.degrees(bpy.context.scene.sna_tcp.rotation_euler[1]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[2])]
            distance_to_target = math.sqrt(sum([(a - b) ** 2 for a, b in zip(current_position[:3], newPos[:3])]))
            print(round(distance_to_target, 4))
            #bpy.context.scene.sna_x = currentPos[1][0] 
            robot.set_position(x=newPos[0] , y=newPos[1] , z=newPos[2] , roll=newPos[3], pitch=newPos[4], yaw=newPos[5], speed=100, wait=False)
            print("start")
            return newPos

        def modal():
            current_position = robot.get_position()[1]
            distance_to_target = math.sqrt(sum([(a - b) ** 2 for a, b in zip(current_position[:3], newPos[:3])]))
            print(print(round(distance_to_target, 4)))
            if round(distance_to_target, 4) < 0.1:
                print("done") 
                print("Distance " + str(round(distance_to_target, 4)))   
                return {'FINISHED'}
            return {'PASS_THROUGH'}

        def after():
            get_robotPos()
        return_7F3AD = after()
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _A4C67_running
        if not context.area or not _A4C67_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:

            def before():
                robot.motion_enable(enable=True)
                robot.set_mode(0)
                robot.set_state(state=0)
                current_position = robot.get_position()[1]
                newPos = [bpy.context.scene.sna_tcp.location[0],bpy.context.scene.sna_tcp.location[1],bpy.context.scene.sna_tcp.location[2],math.degrees(bpy.context.scene.sna_tcp.rotation_euler[0])+180,math.degrees(bpy.context.scene.sna_tcp.rotation_euler[1]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[2])]
                distance_to_target = math.sqrt(sum([(a - b) ** 2 for a, b in zip(current_position[:3], newPos[:3])]))
                print(round(distance_to_target, 4))
                #bpy.context.scene.sna_x = currentPos[1][0] 
                robot.set_position(x=newPos[0] , y=newPos[1] , z=newPos[2] , roll=newPos[3], pitch=newPos[4], yaw=newPos[5], speed=100, wait=False)
                print("start")
                return newPos

            def modal():
                current_position = robot.get_position()[1]
                distance_to_target = math.sqrt(sum([(a - b) ** 2 for a, b in zip(current_position[:3], newPos[:3])]))
                print(print(round(distance_to_target, 4)))
                if round(distance_to_target, 4) < 0.1:
                    print("done") 
                    print("Distance " + str(round(distance_to_target, 4)))   
                    return {'FINISHED'}
                return {'PASS_THROUGH'}

            def after():
                get_robotPos()
            return_A1D69 = modal(newPos=return_C2D7F)
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _A4C67_running
        if _A4C67_running:
            _A4C67_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)

            def before():
                robot.motion_enable(enable=True)
                robot.set_mode(0)
                robot.set_state(state=0)
                current_position = robot.get_position()[1]
                newPos = [bpy.context.scene.sna_tcp.location[0],bpy.context.scene.sna_tcp.location[1],bpy.context.scene.sna_tcp.location[2],math.degrees(bpy.context.scene.sna_tcp.rotation_euler[0])+180,math.degrees(bpy.context.scene.sna_tcp.rotation_euler[1]),math.degrees(bpy.context.scene.sna_tcp.rotation_euler[2])]
                distance_to_target = math.sqrt(sum([(a - b) ** 2 for a, b in zip(current_position[:3], newPos[:3])]))
                print(round(distance_to_target, 4))
                #bpy.context.scene.sna_x = currentPos[1][0] 
                robot.set_position(x=newPos[0] , y=newPos[1] , z=newPos[2] , roll=newPos[3], pitch=newPos[4], yaw=newPos[5], speed=100, wait=False)
                print("start")
                return newPos

            def modal():
                current_position = robot.get_position()[1]
                distance_to_target = math.sqrt(sum([(a - b) ** 2 for a, b in zip(current_position[:3], newPos[:3])]))
                print(print(round(distance_to_target, 4)))
                if round(distance_to_target, 4) < 0.1:
                    print("done") 
                    print("Distance " + str(round(distance_to_target, 4)))   
                    return {'FINISHED'}
                return {'PASS_THROUGH'}

            def after():
                get_robotPos()
            return_C2D7F = before()
            context.window_manager.modal_handler_add(self)
            _A4C67_running = True
            return {'RUNNING_MODAL'}


class SNA_PT_COMMANDS_2ECE1(bpy.types.Panel):
    bl_label = 'Commands'
    bl_idname = 'SNA_PT_COMMANDS_2ECE1'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Animaquina'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_1F9C7 = layout.column(heading='', align=True)
        col_1F9C7.alert = False
        col_1F9C7.enabled = True
        col_1F9C7.active = True
        col_1F9C7.use_property_split = False
        col_1F9C7.use_property_decorate = False
        col_1F9C7.scale_x = 1.0
        col_1F9C7.scale_y = 1.0
        col_1F9C7.alignment = 'Left'.upper()
        col_1F9C7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_1F9C7.label(text='Command', icon_value=0)
        op = col_1F9C7.operator('sna.home_47dfc', text='Home', icon_value=655, emboss=True, depress=False)
        op = col_1F9C7.operator('sna.update_pose_d5d92', text='Update Pose', icon_value=35, emboss=True, depress=False)
        op = col_1F9C7.operator('sna.manualmode_edd6d', text='Manual Mode', icon_value=778, emboss=True, depress=bpy.context.scene.sna_manualmode)
        op = col_1F9C7.operator('sna.realtime_c6c51', text='RealTime', icon_value=118, emboss=True, depress=bpy.context.scene.sna_realtime)
        col_1F9C7.prop(bpy.context.scene, 'sna_tcp', text='TARGET', icon_value=0, emboss=True)
        col_1F9C7.prop(bpy.context.scene, 'sna_tool', text='TOOL', icon_value=0, emboss=True)
        col_1F9C7.prop(bpy.context.scene, 'sna_simcollection', text='Sim Collection', icon_value=0, emboss=True)
        op = col_1F9C7.operator('sna.settool_e3389', text='Set Tool', icon_value=94, emboss=True, depress=False)
        op = col_1F9C7.operator('sna.setsim_8afa7', text='Set Simulation', icon_value=571, emboss=True, depress=False)
        op = col_1F9C7.operator('sna.gotort_746a0', text='goTarget', icon_value=274, emboss=True, depress=False)


class SNA_PT_INFO_A49A7(bpy.types.Panel):
    bl_label = 'Info'
    bl_idname = 'SNA_PT_INFO_A49A7'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Animaquina'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_00E0F = layout.column(heading='TCP position', align=True)
        col_00E0F.alert = False
        col_00E0F.enabled = True
        col_00E0F.active = True
        col_00E0F.use_property_split = False
        col_00E0F.use_property_decorate = False
        col_00E0F.scale_x = 1.0
        col_00E0F.scale_y = 1.0
        col_00E0F.alignment = 'Expand'.upper()
        col_00E0F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_00E0F.prop(bpy.context.scene, 'sna_x', text='X', icon_value=0, emboss=False, slider=True)
        col_00E0F.prop(bpy.context.scene, 'sna_y', text='Y', icon_value=0, emboss=False, slider=False)
        col_00E0F.prop(bpy.context.scene, 'sna_z', text='Z', icon_value=0, emboss=False)
        col_00E0F.prop(bpy.context.scene, 'sna_a', text='A', icon_value=0, emboss=False)
        col_00E0F.prop(bpy.context.scene, 'sna_b', text='B', icon_value=0, emboss=False)
        col_00E0F.prop(bpy.context.scene, 'sna_c', text='C', icon_value=0, emboss=False)
        col_9F6C0 = layout.column(heading='Joint Angles', align=True)
        col_9F6C0.alert = False
        col_9F6C0.enabled = True
        col_9F6C0.active = True
        col_9F6C0.use_property_split = False
        col_9F6C0.use_property_decorate = True
        col_9F6C0.scale_x = 1.0
        col_9F6C0.scale_y = 1.0
        col_9F6C0.alignment = 'Expand'.upper()
        col_9F6C0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_9F6C0.prop(bpy.context.scene, 'sna_j1', text='j1', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j2', text='j2', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j3', text='j3', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j4', text='j4', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j5', text='j5', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j6', text='j6', icon_value=0, emboss=False)


class SNA_OT_Settool_E3389(bpy.types.Operator):
    bl_idname = "sna.settool_e3389"
    bl_label = "setTool"
    bl_description = "set the offset on the selected tool"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_6CE04 = setTool()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Setsim_8Afa7(bpy.types.Operator):
    bl_idname = "sna.setsim_8afa7"
    bl_label = "setSim"
    bl_description = "Set a duplicated colection for simulation"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_627C3 = setSimulation()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_j1 = bpy.props.FloatProperty(name='j1', description='j1', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j2 = bpy.props.FloatProperty(name='j2', description='j2', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j3 = bpy.props.FloatProperty(name='j3', description='j3', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j4 = bpy.props.FloatProperty(name='j4', description='j4', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j5 = bpy.props.FloatProperty(name='j5', description='j5', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j6 = bpy.props.FloatProperty(name='j6', description='j6', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_x = bpy.props.FloatProperty(name='X', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=3)
    bpy.types.Scene.sna_y = bpy.props.FloatProperty(name='Y', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=3)
    bpy.types.Scene.sna_z = bpy.props.FloatProperty(name='Z', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=3)
    bpy.types.Scene.sna_a = bpy.props.FloatProperty(name='A', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=3)
    bpy.types.Scene.sna_b = bpy.props.FloatProperty(name='B', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=3)
    bpy.types.Scene.sna_c = bpy.props.FloatProperty(name='C', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=3)
    bpy.types.Scene.sna_ip = bpy.props.StringProperty(name='IP', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_tcp = bpy.props.PointerProperty(name='tcp', description='', type=bpy.types.Object)
    bpy.types.Scene.sna_manualmode = bpy.props.BoolProperty(name='manualmode', description='', default=False)
    bpy.types.Scene.sna_tool = bpy.props.PointerProperty(name='tool', description='select tool', type=bpy.types.Object)
    bpy.types.Scene.sna_realtime = bpy.props.BoolProperty(name='realtime', description='', default=False)
    bpy.types.Scene.sna_robot = bpy.props.PointerProperty(name='robot', description='', type=bpy.types.Object)
    bpy.types.Scene.sna_acc = bpy.props.FloatProperty(name='acc', description='', default=50.0, subtype='NONE', unit='NONE', min=0.0, max=200.0, step=3, precision=4)
    bpy.types.Scene.sna_vel = bpy.props.FloatProperty(name='vel', description='', default=50.0, subtype='NONE', unit='NONE', min=0.0, max=100.0, step=3, precision=4)
    bpy.types.Scene.sna_rad = bpy.props.FloatProperty(name='rad', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=4)
    bpy.types.Scene.sna_simcollection = bpy.props.PointerProperty(name='simcollection', description='', type=bpy.types.Collection)
    bpy.utils.register_class(SNA_OT_Disconnect__Robot_B5347)
    bpy.utils.register_class(SNA_OT_Connect_Robot_3Efab)
    bpy.utils.register_class(SNA_OT_Update_Pose_D5D92)
    bpy.utils.register_class(SNA_OT_Manualmode_Edd6D)
    bpy.utils.register_class(SNA_OT_Addmarker_2E3A1)
    bpy.utils.register_class(SNA_OT_Home_47Dfc)
    bpy.utils.register_class(SNA_OT_Jog_13671)
    bpy.utils.register_class(SNA_OT_Installsdk_F915B)
    bpy.utils.register_class(SNA_PT_SETUP_2240C)
    bpy.utils.register_class(SNA_PT_TOOLPATHING_95AA3)
    bpy.utils.register_class(SNA_OT_Runpathold_D30Df)
    bpy.utils.register_class(SNA_OT_Debug_C0948)
    bpy.utils.register_class(SNA_OT_Realtime_C6C51)
    bpy.utils.register_class(SNA_OT_Runpath_C74D7)
    bpy.utils.register_class(SNA_OT_Gototargetmod_Bcb48)
    bpy.utils.register_class(SNA_OT_Gotort_746A0)
    bpy.utils.register_class(SNA_OT_Gototarget_2Cfb1)
    bpy.utils.register_class(SNA_OT_Testptp_A4C67)
    bpy.utils.register_class(SNA_PT_COMMANDS_2ECE1)
    bpy.utils.register_class(SNA_PT_INFO_A49A7)
    bpy.utils.register_class(SNA_OT_Settool_E3389)
    bpy.utils.register_class(SNA_OT_Setsim_8Afa7)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_simcollection
    del bpy.types.Scene.sna_rad
    del bpy.types.Scene.sna_vel
    del bpy.types.Scene.sna_acc
    del bpy.types.Scene.sna_robot
    del bpy.types.Scene.sna_realtime
    del bpy.types.Scene.sna_tool
    del bpy.types.Scene.sna_manualmode
    del bpy.types.Scene.sna_tcp
    del bpy.types.Scene.sna_ip
    del bpy.types.Scene.sna_c
    del bpy.types.Scene.sna_b
    del bpy.types.Scene.sna_a
    del bpy.types.Scene.sna_z
    del bpy.types.Scene.sna_y
    del bpy.types.Scene.sna_x
    del bpy.types.Scene.sna_j6
    del bpy.types.Scene.sna_j5
    del bpy.types.Scene.sna_j4
    del bpy.types.Scene.sna_j3
    del bpy.types.Scene.sna_j2
    del bpy.types.Scene.sna_j1
    bpy.utils.unregister_class(SNA_OT_Disconnect__Robot_B5347)
    bpy.utils.unregister_class(SNA_OT_Connect_Robot_3Efab)
    bpy.utils.unregister_class(SNA_OT_Update_Pose_D5D92)
    bpy.utils.unregister_class(SNA_OT_Manualmode_Edd6D)
    bpy.utils.unregister_class(SNA_OT_Addmarker_2E3A1)
    bpy.utils.unregister_class(SNA_OT_Home_47Dfc)
    bpy.utils.unregister_class(SNA_OT_Jog_13671)
    bpy.utils.unregister_class(SNA_OT_Installsdk_F915B)
    bpy.utils.unregister_class(SNA_PT_SETUP_2240C)
    bpy.utils.unregister_class(SNA_PT_TOOLPATHING_95AA3)
    bpy.utils.unregister_class(SNA_OT_Runpathold_D30Df)
    bpy.utils.unregister_class(SNA_OT_Debug_C0948)
    bpy.utils.unregister_class(SNA_OT_Realtime_C6C51)
    bpy.utils.unregister_class(SNA_OT_Runpath_C74D7)
    bpy.utils.unregister_class(SNA_OT_Gototargetmod_Bcb48)
    bpy.utils.unregister_class(SNA_OT_Gotort_746A0)
    bpy.utils.unregister_class(SNA_OT_Gototarget_2Cfb1)
    bpy.utils.unregister_class(SNA_OT_Testptp_A4C67)
    bpy.utils.unregister_class(SNA_PT_COMMANDS_2ECE1)
    bpy.utils.unregister_class(SNA_PT_INFO_A49A7)
    bpy.utils.unregister_class(SNA_OT_Settool_E3389)
    bpy.utils.unregister_class(SNA_OT_Setsim_8Afa7)
